<template>
  <div class="container">
    <div class="home-link">
      <h1>Resume</h1>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style scoped>
.home-link {
  display: flex;
  justify-content: space-evenly;
  flex-wrap: wrap;
  width: 500px;
}
</style>
