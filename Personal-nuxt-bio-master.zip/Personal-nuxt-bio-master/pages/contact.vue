<template>
  <div class="container">
    <div class="home-link">
      <h1>Contact</h1>
    </div>
  </div>
</template>

<script>
export default {}
</script>

<style>
</style>
